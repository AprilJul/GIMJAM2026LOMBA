extends CanvasLayer

@export var placed_hallways_node: Node2D

var grid_size = 64
var inventory = {"straight": 3, "turn": 1}
var dragged_hallway: Node2D = null
var placed_previews: Array = []

func _ready():
	visible = false

func open_map():
	visible = true

func close_map():
	visible = false
	for child in placed_hallways_node.get_children():
		child.queue_free()
	
	for p in placed_previews:
		var path = ""
		if p.type == "straight":
			if p.rotation == 0 or p.rotation == 2:
				path = "res://rooms/hallways/hallway_straight_vertical.tscn"
			else:
				path = "res://rooms/hallways/hallway_straight_horizontal.tscn"
		elif p.type == "turn":
			path = "res://rooms/hallways/hallway_turn.tscn"
		
		if ResourceLoader.exists(path):
			var instance = load(path).instantiate()
			instance.position = Vector2(p.grid_pos) * grid_size + Vector2(grid_size / 2, grid_size / 2)
			instance.rotation_degrees = p.rotation * 90
			placed_hallways_node.add_child(instance)
	
	placed_previews.clear()

func _input(event):
	if !visible:
		return

	if event.is_action_pressed("place_straight"):
		_start_drag("straight")
	elif event.is_action_pressed("place_turn"):
		_start_drag("turn")

	if event.is_action_pressed("rotate_left") and dragged_hallway:
		dragged_hallway.rotate_left()
	if event.is_action_pressed("rotate_right") and dragged_hallway:
		dragged_hallway.rotate_right()

	if event.is_action_pressed("ui_accept") and dragged_hallway:
		if inventory[dragged_hallway.type] > 0:
			if GameManager.spend_sanity(1):
				_place_preview()
		_cancel_drag()

	if event.is_action_pressed("ui_cancel"):
		_cancel_drag()

func _process(delta):
	if visible and dragged_hallway:
		var screen_pos = get_viewport().get_mouse_position()
		var canvas_transform = get_viewport().get_canvas_transform()
		var world_pos = canvas_transform.affine_inverse() * screen_pos  # ← USE MULTIPLICATION
		var grid_pos = (world_pos / grid_size).floor()
		dragged_hallway.position = grid_pos * grid_size + Vector2(grid_size / 2, grid_size / 2)

func _start_drag(type: String):
	if inventory[type] <= 0:
		return
	var preview = preload("res://rooms/hallways/hallway_preview.tscn").instantiate()
	preview.type = type
	dragged_hallway = preview
	add_child(dragged_hallway)

func _place_preview():
	if !dragged_hallway:
		return

	var screen_pos = get_viewport().get_mouse_position()
	var canvas_transform = get_viewport().get_canvas_transform()
	var world_pos = canvas_transform.affine_inverse() * screen_pos  # ← USE MULTIPLICATION
	var grid_pos = (world_pos / grid_size).floor()
	
	for p in placed_previews:
		if p.grid_pos == grid_pos:
			return
	
	placed_previews.append({
		"type": dragged_hallway.type,
		"grid_pos": grid_pos,
		"rotation": dragged_hallway.current_rotation_index
	})
	inventory[dragged_hallway.type] -= 1

func _cancel_drag():
	if dragged_hallway:
		dragged_hallway.queue_free()
		dragged_hallway = null

extends Node2D

@onready var map_system = $MapSystem

func _input(event):
	if event.is_action_pressed("toggle_map"):
		if map_system.visible:
			map_system.close_map()
		else:
			map_system.open_map()
